#!/usr/bin/env python

from distutils.core import setup

scripts = ["np-test"]
pkgs = ["pkgs", "pkgs.tools", "pkgs.physics", "pkgs.testsuite",
        "pkgs.py4gmsh", "pkgs.H_cyl_geo", "pkgs.H_geo"]

setup(name = "fenics-np",
      version = "0.5",
      description = "Nanopore Simulations with FEniCS",
      author = "Gregor Mitscha-Eibl and Andreas Buttinger-Kreuzhuber",
      author_email = "gregor.mitscha-eibl@tuwien.ac.at",
      url = "https://gitlab.asc.tuwien.ac.at/",
      packages = pkgs,
      scripts = scripts,
      data_files = [])
