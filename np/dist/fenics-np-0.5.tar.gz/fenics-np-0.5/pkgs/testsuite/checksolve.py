def check_solve(p):
    iterations = p.newton_solve()
    if iterations > 15:
        raise SystemExit("Newton didn't converge")


