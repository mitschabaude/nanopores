from pkgs import *
from checksolve import check_solve

name2D = "H_geo"
IllposedLinearSolver.solver = "mumps"

# 2D
generate_mesh(2.0, name2D, dim=2)
geo = geo_from_name(name2D)
p = PNPSAxisym(geo)
check_solve(p)

