from pkgs import *
from checksolve import check_solve

from dolfin import set_log_level
set_log_level(100)

name3D = "H_cyl_geo"
IllposedLinearSolver.solver = "mumps"

# 3D without molecule
generate_mesh(15.0, name3D)
geo = geo_from_name(name3D)
p = PNPS(geo)
check_solve(p)
