"""
python function that writes geo for given geometry and xml for fenics
"""

from subprocess import call

def get_meshxml(clscale, gid = "H_geo"):
    """
    Input: clscale... scaling of characteristic length in gmsh [float]
           gid (optional)... geometry identifier [string] (default: "H_geo")
    Out: fid_xml... file identifier of xml mesh file
    """

    hstr = ("%s.py4geo" %gid)
    print "path", hstr
    exec('from %s import get_geo' %hstr)

    fid_geo = ("pkgs/%s/mesh/input.geo" %gid)
    fid_msh = ("pkgs/%s/mesh/out.msh" %gid)
    fid_xml = ("pkgs/%s/mesh/mesh.xml" %gid)

    # save code to .geo file
    fobj = open(fid_geo, "w")
    fobj.write(get_geo())
    fobj.close()

    # after writing the geo file, call gmsh
    call(["gmsh", "-2", "-clscale", "%f" %clscale, fid_geo, "-o", fid_msh])
    call(["dolfin-convert", fid_msh, fid_xml])

    print("The new mesh xml file is found in %s" %fid_xml)

    return fid_xml
    
    
def get_mesh(clscale, gid, xml = True):
    """
    Input: clscale... scaling of characteristic length in gmsh [float]
           gid ... geometry identifier [string]
           xml(optional)[bool][True]
    Out: fid... file identifier of xml mesh file
    """

    hstr = ("%s.py4geo" %gid)
    exec('from %s import get_3Dgeo' %hstr)

    fid_geo = ("pkgs/%s/mesh/input.geo" %gid)
    fid_msh = ("pkgs/%s/mesh/out.msh" %gid)
    fid_xml = ("pkgs/%s/mesh/mesh.xml" %gid)

    # save code to .geo file
    fobj = open(fid_geo, "w")
    fobj.write(get_3Dgeo())
    fobj.close()

    # after writing the geo file, call gmsh
    call(["gmsh", "-3", "-v", "1","-clscale", "%f" %clscale, fid_geo, "-o", fid_msh])
    if xml:
        call(["dolfin-convert", fid_msh, fid_xml])
        print("The new mesh xml file is found in %s" %fid_xml)
        return fid_xml

    else:
        print("The new mesh geo file is found in %s" %fid_geo)
        return fid_geo


# -----
# to test script run '>python -m pkgs.geo2xml.py'
if __name__ == '__main__':
    print(get_mesh(10.0, gid = "H_cyl", xml=False))
