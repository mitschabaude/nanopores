"""
physical parameters for Simulations
"""
from dolfin import Constant

nm = 1e-9

# Define constants taken from
# 'Effective force applied on DNA inside a solid-state nanopore'
qq = 1.602e-19  # elementary charge [C]
mol = 6.022e23  # Avogadro
cFarad = 96320.0  # Faraday [C/mol] cFarad=qq*mol
D = 1.9e-9  # Diffusion [m^2/s]
mu = 73e-9  # average mobility [m^2/Vs]
eta = 1e-3  # fluid viscosity [Pa s]
rho = 1e3 # fluid density [kg/m^3]
eperm = 8.854e-12  # electrical permittivity [F/m]
rpermw = 80.2  # relative permittivity of water
rpermMembraneSiN = 7.0  # relative permittivity of SiN (http://www.iue.tuwien.ac.at/phd/quay/node27.html)
rpermMembraneLipid = 2.0  # relative permittivity of a lipid bilayer  # @TODO
rpermDNA = 40.0  # Paper (???)  # @TODO
UT = 0.026  # thermal voltage [V] ( kB*T/qq)

bV = 0.1  # biased Voltage [V]
bulkcon = 1e3  # bulk concentration [mol/m^3]

MembraneSiNqs = -30.0e-3  # SiN Membrane surface charge [C/m^2]
#MembraneLipidqs = 0.0  # Lipid bilayer Membrane surface charge [C/m^2]
bpq=-2*qq  #charge per base pair -keyser.pdf
distbp = 0.34*nm  # distance between two base pairs for dsDNA -keyser.pdf
DNAql = bpq/distbp  # line charge of dsDNA
DNAqs = -136.2e-3  # DNA surface charge [C/m^2]  # @FIXME

# @FIXME  integration over surface should give total charge ! surface depends on geometry !
f_Moleculeqs = Constant(-qq/(4*3.1415*0.5*1.1**2))
f_DNAqs = Constant(DNAqs)

# Define overall used constant functions
f_0 = Constant(0.0)
f_1 = Constant(1.0)
f_bV = Constant(bV)
f_bulkcon = Constant(bulkcon)
f_Membraneqs = Constant(MembraneSiNqs)
f_DNAql = Constant(DNAql)
A_fluid = eperm*rpermw
A_DNA = eperm*rpermDNA
A_SiN = eperm*rpermMembraneSiN
A_Lipid = eperm*rpermMembraneLipid

permittivity = {
    'fluid':A_fluid,
    'dna':A_DNA,
    'molecule':A_DNA,
    'sin':A_SiN,
    'lipid':A_Lipid,
}

diffusion_factor = {
    'fluid':1,
    'dna':0.01,
    'molecule':0.01,
    'sin':0.0001,
    'lipid':0.0001,
}

initial_ions = {
    'fluid':bulkcon,
    'dna':0.0,
    'sin':0.0,
    'lipid':0.0,
    'molecule':0.0,
}

