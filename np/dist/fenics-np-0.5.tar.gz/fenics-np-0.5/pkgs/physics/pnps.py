""" Define PNP-Stokes related problems """

from dolfin import *
from ..tools import *
from .params_physical import *
from warnings import warn

parameters["allow_extrapolation"] = True
parameters["refinement_algorithm"] = "plaza_with_parent_facets"

__all__ = ["PNPS","PNPProblem","StokesProblem"]

class PNPS(PDESystem):
    imax = 50
    tolnewton = 1e-2
    maxcells = 10000
    marking_fraction = 0.5

    def __init__(self, geo):
        # TODO: initialization in 3D takes more than 3 seconds, even without assembling Stokes.
        #       where is the time spent? in the imports?
        mesh = geo.mesh
        
        X = PNPProblem.space(mesh)
        W = StokesProblem.space(mesh)
        
        x = Function(X)
        w = Function(W)
        
        V = X.sub(0).collapse()
        c0 = interpolate(geo.pwconst('initial_ions'),V)
        assign(x, [interpolate(Constant(0.0),V), c0, c0])
        #x.interpolate(Constant((0.0, bulkcon, bulkcon)))
        
        geo.BC(X.sub(0), Constant(bV), "lowerb").apply(x.vector())
        geo.BC(X.sub(1), Constant(bulkcon), "bulk").apply(x.vector())
        geo.BC(X.sub(2), Constant(bulkcon), "bulk").apply(x.vector())
        
        (vold, cpold, cmold) = x.split()
        (uold, pold) = w.split()

        fstokes = -cFarad*(cpold - cmold)*grad(vold)
        
        # Problem Definitions
        pnpproblem = PNPProblem(geo, x=x, w=w)
        stokesproblem = StokesProblem(geo, f=fstokes, w=w)

        PNP = IllposedNonlinearSolver(pnpproblem)
        Stokes = IllposedLinearSolver(stokesproblem,reuse=True)
        
        # Goal Functionals for force, current
        dS = geo.dS("moleculeb")
        n = FacetNormal(mesh)
        
        FEOMlf = (eta*grad(uold[1])[0])('+')*dS
        FEOM = Functional(FEOMlf)
        
        Jm = (-D*grad(cmold) + mu*cmold*grad(vold) + cmold*uold)
        Jp = (-D*grad(cpold) - mu*cpold*grad(vold) + cpold*uold)
        Jz = (Jm + Jp)[2]
        
        Jtop = Functional(cFarad* avg(Jz) * geo.dS("crosstop2d"))
        Jctrtop = Functional(cFarad* avg(Jz) * geo.dS("crosscentertop2d"))
        Jctrbtm = Functional(cFarad* avg(Jz) * geo.dS("crosscenterbottom2d"))
        Jbtm = Functional(cFarad* avg(Jz) * geo.dS("crossbottom2d"))
        
        # Jtop = Functional(cFarad*dot(avg(J),n('+')) * geo.dS("crosstop2d"))
        # Jctrtop = Functional(cFarad*dot(avg(J),n('+')) * geo.dS("crosscentertop2d"))
        # Jctrbtm = Functional(cFarad*dot(avg(J),n('+')) * geo.dS("crosscenterbottom2d"))
        # Jbtm = Functional(cFarad*dot(avg(J),n('+')) * geo.dS("crossbottom2d"))
        
        pore_length = geo.parameter("l0")
        Javg = Functional(cFarad/pore_length * Jz * geo.dx("porecenter"))

        self.geo = geo
        self.functions = {"PNP":x,"Stokes":w}
        self.solvers = {"PNP":PNP,"Stokes":Stokes}
        self.functionals = {"FEOM":FEOM,
                            "Jtop":Jtop,
                            "Jctrtop":Jctrtop,
                            "Jctrbtm":Jctrbtm,
                            "Jbtm":Jbtm,
                            "Javg":Javg}

    def solve(self, refinement=False, visualize=False, save_mesh=False):
        #if not refinement:
        #    newton_iter = self.newton_solve()
        #    print "Newton iterations:", newton_iter
        #    return

        if refinement and self.geo.mesh.num_cells() > self.maxcells:
            print 'Initial mesh has more than maximal number of cells',  \
                           ' \n  ==> no refinement \n'
            refinement = False

        for i in range(self.imax):
            print '\n- Loop ' +str(i+1) + ' of max.', self.imax
            timer = Timer('Solving step '+str(i+1))

            if refinement:            
                newton_iter = self.newton_solve()
                print "Newton iterations:", newton_iter
            else:
                self.single_solve()
                if self.solvers["PNP"].convergence(self.tolnewton):
                    print 'linf Norm of Newton update:', \
                        norm(self.solvers["PNP"].problem.u.vector(),'linf'), \
                        '<=', self.tolnewton ,' \n  ==> break loop \n'
                    break

            print 'Relative H1 Newton error:',\
                            self.solvers["PNP"].relerror()

            (ind,err) = self.estimate()
            print "Relative error estimate (H1):",err
            #plot(sqrt(ind), title="sqrt(ind) "+str(i+1))
            #interactive()
            
            if save_mesh:
                self.save_mesh(save_mesh)
            if visualize:
                self.visualize(visualize)

            self.print_functionals()

            if refinement:
                refined = self.refine(ind)
                if not refined:
                    timer.stop()
                    print "Loop timing:",timer.value()
                    print 'Maximal number of cells reached',  \
                           ' \n  ==> no more refinement \n'
                    break
                    
            timer.stop()
            print "Loop timing:",timer.value()
        end
        #interactive()

    def estimate(self):
        """ simple residual indicator, estimator """
        return poisson_indicator(self.geo, self.functions["PNP"])

    def newton_solve(self,tol=None):
        if not tol:
            tol = self.tolnewton

        for i in range(self.imax):
            #self.visualize()
            self.single_solve()
            if self.solvers["PNP"].convergence(tol):
                break
        return i

    def estimate_zz(self):
        (v,cp,cm,u,p) = self.solutions()

        Aperm = self.geo.pwconst('permittivity')
        
        #fluxes, normalized to have about the same magnitude
        Jv = Aperm*grad(v)/eperm
        Jm = (D*grad(cm) - mu*cm*grad(v) - cm*u)/(D*bulkcon)
        Jp = (D*grad(cp) + mu*cp*grad(v) - cp*u)/(D*bulkcon)

        indv, errv = zz_indicator(v, Jv)
        indm, errm = zz_indicator(cm, Jm, self.geo.dx('fluid'))
        indp, errp = zz_indicator(cp, Jp, self.geo.dx('fluid'))

        #plot(sqrt(indv), title="sqrt(indv)")
        #plot(sqrt(indm), title="sqrt(indm)")
        #plot(sqrt(indp), title="sqrt(indp)")

        ind = Function(FunctionSpace(self.geo.mesh,"DG",0))
        ind.vector()[:] = indv.vector()[:] + indm.vector()[:] + indp.vector()[:]

        err = (errv + errm + errp)/3

        return (ind,err)

    def visualize(self, subdomain=None):
        (v,cp,cm,u,p) = self.solutions(deepcopy=True)
        
        mesh = self.geo.mesh
        on = ""
        
        if subdomain:
            on = " on " + subdomain
            mesh = self.geo.submesh(subdomain)
            for f in (v,cp,cm,u,p):
                adaptfunction(f,mesh,assign=True)
        
        plot(mesh,title="final mesh"+on)
        plot(v, title='potential'+on)
        plot(cm, title='negative ion concentration'+on)
        plot(cp, title='positive ion concentration'+on)
        plot(u, title='velocity'+on)

        interactive()   

    def print_functionals(self):
        print 'FEOM on Molecule [pN]:', self.functionals["FEOM"]()*1e12
        print 'current (avg) [pA]:', self.functionals["Javg"]()*1e12
        print 'current (top) [pA]:', self.functionals["Jtop"]()*1e12
        print 'current (ctrtop) [pA]:', self.functionals["Jctrtop"]()*1e12
        print 'current (ctrbtm) [pA]:', self.functionals["Jctrbtm"]()*1e12
        print 'current (btm) [pA]:', self.functionals["Jbtm"]()*1e12

    def print_results(self):
        pass

    def solutions(self, string=None, deepcopy=False):
        if string:
            return self.functions[string].split(deepcopy=deepcopy)
        return self.solutions("PNP", deepcopy) + self.solutions("Stokes", deepcopy)
        
    def rebuild(self, mesh):
        """ Assumes geometry to have geo.rebuild """
        # TODO: This is initially a lot slower than PDESystem.rebuild (why?),
        # but seems to be faster in the long run when meshes get large
        
        # save functional evaluations
        functionals = self.functionals
        functions = self.functions
        
        for f in functions:
            adaptfunction(functions[f], mesh, assign=True)
        
        self.geo.rebuild(mesh)
        self.__init__(self.geo)
        
        # TODO: is this 'hack' acceptable?
        newfunctions = {s:functions[s] for s,S in self.solvers.items()
                             if isinstance(S, IllposedNonlinearSolver)}
        oldfs = tuple(self.functions.values())
        self.functions.update(newfunctions)
        newfs = tuple(self.functions.values())
        
        for s,S in self.solvers.items():
            if isinstance(S, IllposedNonlinearSolver):
                # ugly
                S.problem.uold = self.functions[s]
            S.replace(oldfs,newfs)
         
        for Jstr,J in self.functionals.items():
            J.replace(oldfs,newfs)
            J.values = functionals[Jstr].values

    # TODO: Why is adapt not working in 3D????
    # workaround for the time being:
    #adapt = rebuild


class StokesProblem(AdaptableLinearProblem):
    k = 2

    @staticmethod
    def space(mesh):
        k = StokesProblem.k
        U = VectorFunctionSpace(mesh, 'CG', k)
        P = FunctionSpace(mesh, 'CG', k-1)
        return U*P

    def __init__(self, geo, f=None, bcs=None, w=None):
        mesh = geo.mesh
        W = self.space(mesh)

        (u, p) = TrialFunctions(W)
        (v, q) = TestFunctions(W)

        dx = geo.dx("fluid")

        a = (eta*inner(grad(u),grad(v)) + div(v)*p + q*div(u))*dx
        L = inner(f,v)*dx if f else None

        if not w:
            w = Function(W)

        if not bcs:
            try:
                bcs = [geo.BC(W.sub(0), Constant((0.0,0.0,0.0)), "noslip"),
                       geo.BC(W.sub(1), Constant(0.0), "nopressure")]
            except:
                warn("No boundary conditions have been assigned to %s" %type(self).__name__)
        
        AdaptableLinearProblem.__init__(self,a,L,w,bcs,geo.boundaries)


class PNPProblem(AdaptableNonlinearProblem):
    k = 1

    @staticmethod
    def space(mesh):        
        V = FunctionSpace(mesh, 'CG', PNPProblem.k)
        return MixedFunctionSpace((V, V, V))

    def __init__(self, geo, bcs=None, x=None, w=None):
        mesh = geo.mesh
        X = self.space(mesh)

        (v, cp, cm) = TrialFunctions(X)
        (vv, dp, dm) = TestFunctions(X)

        if not x:
            x = Function(X)
            x.interpolate(Constant((0.0, bulkcon, bulkcon)))
            geo.BC(X.sub(0), Constant(bV), "lowerb").apply(x.vector())
        if not w:
            w = Function(StokesProblem.space(mesh))
        
        (uold, pold) = w.split()    
        (vold, cpold, cmold) = x.split()

        dx = geo.dx()
        dx_ions = geo.dx('ions')
        dS_cDNA = geo.dS('chargeddnab')
        dS_Mol = geo.dS('moleculeb')

        Aperm = geo.pwconst('permittivity')
        C = geo.pwconst('diffusion_factor')

        apoisson = inner(Aperm*grad(v),grad(vv))*dx - cFarad*(cp - cm)*vv*dx_ions
        aJm = C*inner(D*grad(cm) - mu*(cm*grad(vold) + cmold*grad(v)) - cm*uold, grad(dm))*dx_ions
        aJp = C*inner(D*grad(cp) + mu*(cp*grad(vold) + cpold*grad(v)) - cp*uold, grad(dp))*dx_ions
        a = apoisson + aJm + aJp

        Lpoisson = inner(Aperm*grad(vold),grad(vv))*dx - cFarad*(cpold - cmold)*vv*dx_ions

        LJm = C*inner(D*grad(cmold) - mu*cmold*grad(vold) - cmold*uold, grad(dm))*dx_ions
        LJp = C*inner(D*grad(cpold) + mu*cpold*grad(vold) - cpold*uold, grad(dp))*dx_ions
        Lq = f_DNAqs*vv('+')*dS_cDNA + f_Moleculeqs*vv('+')*dS_Mol

        L = Lpoisson + LJm + LJp - Lq

        if not bcs:
            try:
                bcs = [geo.BC(X.sub(0), f_0, "upperb"),
                       geo.BC(X.sub(0), f_0, "lowerb"),
                       geo.BC(X.sub(1), f_0, "bulk"),
                       geo.BC(X.sub(2), f_0, "bulk") ]
            except:
                warn("No boundary conditions have been assigned to %s" %type(self).__name__)

        AdaptableNonlinearProblem.__init__(self, a, L, x, bcs, geo.boundaries)

