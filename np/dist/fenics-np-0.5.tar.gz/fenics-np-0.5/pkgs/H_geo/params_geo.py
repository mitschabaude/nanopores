""" --- geometry parameters for Howorka --- """

nm = 1e-9

tolc = 1e-12*nm  # tolerance for coordinate comparisons

# pore radius @center,
r0 = 1*nm #0.75*nm
# barrel outer radius
r1 = 2.75*nm
# pore length @center
l0 = 15.0*nm
# membrane thickness
l1 = 2.2*nm
# Radius of domain
Ry = 15.0*nm
Rx = 15.0*nm

# crosssection height
hc = l1
