"""
mark domains/boundaries with dolfin MeshFunctions
"""

"""
ueberlegungen bzgl. abstraktion:

subdomain numbers werden gebraucht fuer:
-) bilinearformen (masse) --> als tupel
   -> jede variable in (v,ionen,wasser) ist mit einem tupel \subset (0,1,2,..) assoziiert
   -> diese assoziation ist eine geometrische eigenschaft, gehoert daher in geo file
-) fuer potential: permittivity
-) fuer ionen: versch. diffusionskonstanten
-) spaeter fuer wasser vielleicht etwas aehnliches, bei unified continuum mechanics (??)
-) charges, d.h. neumann boundaries fuer potential
   -> moeglicherweise sowohl auf interfaces als auch boundaries
   -> bisher aber nur auf interfaces --> also mass dS
   -> tupel \subset (0,1,2,..) im geo file passend zu boundaries_list()
      UND tupel mit den entsprechenden charges
   -> sowas wie

	Lv = 0.0*dS
	for c in chargedinterfaces
		Lv = Lv + Constant(charge(c))*dS(c)

-) dirichlet boundaries + randwerte

es waere schoen das alles in einer klasse zu haben und nicht alles erst "getten" zu muessen

"""

from dolfin import *
from params_geo import *
#from ..params_physical import *
from ..tools.geometry import *

__all__ = ["get_subdomain","get_boundaries","get_crosssections",
	"get_permittivity_DG","get_diffusion_DG","make_domain","make_boundary","make_geo"]

# lists containing subdomain classes
def subdomain_list(**kwargs):
	return [Fluid(), DNA(), Membrane(), CenterCylinderFluid()]
def boundaries_list(**kwargs):
	return [Upper(), Lower(), LeftFluid(), RightFluid(), ChargedDNA(), UnchargedDNA(),
			MembraneB(), CrossTop2D(), CrossCenter2D(), CrossBottom2D()]

synonymes = {
    "fluid":{"fluid","centercylinderfluid"},
    "center":"centercylinderfluid",
    "ions":{"fluid"},
    #"ions":{"fluid","dna"},
    #"ions":{"fluid","dna","membrane"},
    "bulk":{"upper","lower","rightfluid"},
    "dna":{"chargeddna","unchargeddna"},
    "lipid":"membrane",
    "noslip":{"dna","membraneb"},
    "nopressure":"bulk",
}

#from . import params_geo
#params = vars(params_geo)

# subdomains
class Fluid(SubDomain):
    def inside(self, x, on_boundary):
        return True  # other domains will overwrite

class DNA(SubDomain):
    def inside(self, x, on_boundary):
        return True if (x[0] >= (r0-tolc) and x[0] <= (r1 +tolc)  \
            and (abs(x[1])-tolc) <= 0.5*l0)  \
        else False

class Membrane(SubDomain):
    def inside(self, x, on_boundary):
        return True if x[0] >= (r1 -tolc) and x[0] <= Rx  \
            and abs(x[1]) -tolc <= l1/2  \
            else False

class CenterCylinderFluid(SubDomain):
    def inside(self, x, on_boundary):
	return True if (x[0] >= (0-tolc) and x[0] <= (r0 +tolc)  \
            and (abs(x[1])-tolc) <= 0.5*l0)  \
        else False

# exterior fluid boundaries
class Upper(SubDomain):
    def inside(self, x, on_boundary):
        return on_boundary and near(x[1], Ry)

class Lower(SubDomain):
    def inside(self, x, on_boundary):
        return on_boundary and near(x[1], -Ry)

class LeftFluid(SubDomain):
    def inside(self, x, on_boundary):
        return on_boundary and near(x[0], 0)

class RightFluid(SubDomain):
    def inside(self, x, on_boundary):
        return on_boundary and near(x[0], Rx) and abs(x[1]) >= l1/2 -tolc

# DNA boundaries
class ChargedDNA(SubDomain):
    def inside(self, x, on_boundary):
         return ( ( near(x[0], r0) or near(x[0], r1) ) and  \
             between(abs(x[1]), (l1/2 -tolc, l0/2 +tolc)) )

class UnchargedDNA(SubDomain):
    def inside(self, x, on_boundary):
         return ( ( near(x[0], r0) and between( x[1], (-l1/2 -tolc, l1/2 + tolc) ) )  \
             or  ( between(x[0], (r0 -tolc, r1 +tolc)) and near(abs(x[1]), l0/2) ) )

# Membrane boundaries
class MembraneB(SubDomain):
    def inside(self, x, on_boundary):
         return between(x[0], (r1 -tolc, Rx +tolc)) \
             and near(abs(x[1]), l1/2)

# Center cross-section interfaces
class CrossTop2D(SubDomain):
	def inside(self, x, on_boundary):
		return (near(x[1],l0/2) and between(x[0],(0,r0)))

class CrossCenter2D(SubDomain):
	def inside(self, x, on_boundary):
		return (near(x[1],0.0) and between(x[0],(0,r0)))

class CrossBottom2D(SubDomain):
	def inside(self, x, on_boundary):
		return (near(x[1],-l0/2) and between(x[0],(0,r0)))

# Center cross-section interfaces
class CrossTop(SubDomain):
	def inside(self, x, on_boundary):
		return (between(x[1],(l0/2-hc,l0/2)) and between(x[0],(0,r0)))

class CrossCenter(SubDomain):
	def inside(self, x, on_boundary):
		return (between(x[1],(-hc/2,hc/2)) and between(x[0],(0,r0)))

class CrossBottom(SubDomain):
	def inside(self, x, on_boundary):
		return (between(x[1],(-l0/2,-l0/2+hc)) and between(x[0],(0,r0)))

# get MeshFunctions
def get_subdomain(mesh):
	subdomain = CellFunction("size_t", mesh, 0)
	for i,sub in enumerate(subdomain_list()):
		sub.mark(subdomain, i+1)
	return subdomain

def get_boundaries(mesh):
	boundaries = FacetFunction("size_t", mesh, 0)
	Upper().mark(boundaries, 11)
	Lower().mark(boundaries, 12)
	LeftFluid().mark(boundaries, 13)
	RightFluid().mark(boundaries, 14)
	ChargedDNA().mark(boundaries, 21)
	UnchargedDNA().mark(boundaries, 22)
	MembraneB().mark(boundaries, 31)
	return boundaries

def get_crosssections(mesh):
	crosssections = get_subdomain(mesh)
	CrossTop().mark(crosssections,41)
	CrossCenter().mark(crosssections,42)
	CrossBottom().mark(crosssections,43)
	return crosssections

# get piecewise constant (pwc) function on subdomains (e.g. permittivity)
# specified by list/array either as CellFunction or as DG0 Function
class CellFunction2Expression(Expression):
	def __init__(self, cellfun):
        	self.cellfun = cellfun
	def eval_cell(self, values, x, cell):
		values[0] = self.cellfun[cell.index]

def get_pwc_cellfun(mesh,somearray):
	cellfun = CellFunction("double", mesh)
	for i,sub in enumerate(subdomain_list()):
		sub.mark(cellfun, somearray[i])
	return cellfun

def get_pwc_DG(mesh,somearray):
	cellfun = get_pwc_cellfun(mesh,somearray)
	expr = CellFunction2Expression(cellfun)
	dgfun = Function(FunctionSpace(mesh,"DG",0))
	dgfun.interpolate(expr)
	return dgfun

def get_permittivity_DG(mesh):
	return get_pwc_DG(mesh,perm)

def get_diffusion_DG(mesh):
	return get_pwc_DG(mesh,diff)

