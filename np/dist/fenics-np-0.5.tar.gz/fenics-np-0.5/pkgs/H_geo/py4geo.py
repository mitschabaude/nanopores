"""
python script that generates mesh for Howorka geometry
"""

import numpy, math
from params_geo import *


# -----
def get_geo():
    """
    writes a 2d geo file for an axissymmetric geometry for Howorka
    'Self-Assembled DNA that spans lipid bilayers'
    _________
    |        |
    |  _     |
    | | |____|
    | | |____|
    | |_|    |
    |        |
    |________|

    """

    # characteristic length / mesh size h
    lc = nm
    lcDNA = lc#*1e-2
    lcFluid = lc
    lcMembrane = lc#*5e-1

    X_Fluid = numpy.array([[0, Ry, 0],
                           [Rx, Ry, 0],
                           [Rx, l1/2, 0],
                           [Rx, -l1/2, 0],
                           [Rx, -Ry, 0],
                           [0, -Ry, 0],
                           [0, -l0/2, 0],
                           [0, -l1/2, 0],
                           [0, l1/2, 0],
                           [0, l0/2, 0] ])

    X_DNA = numpy.array([[r0, l0/2, 0],
                         [r1, l0/2, 0],
                         [r1, l1/2, 0],
                         [r1, -l1/2, 0],
                         [r1, -l0/2, 0],
                         [r0, -l0/2, 0],
                         [r0, -l1/2, 0],
                         [r0, l1/2, 0]])

    p_Fluid = [Point(x, lcFluid) for x in X_Fluid]
    p_DNA = [Point(x, lcDNA) for x in X_DNA]

    # Create Line Loops from the points sitting on the line
    Comment(' Connect all Fluid points ')
    e_Fluid = [Line(p_Fluid[k], p_Fluid[k+1]) for k in range(len(p_Fluid)-1)]
    e_Fluid.append(Line(p_Fluid[-1], p_Fluid[0]))
    ll_Fluid = LineLoop(e_Fluid)

    Comment(' Connect all DNA points ')
    e_DNA = [Line(p_DNA[k], p_DNA[k+1]) for k in range(len(p_DNA)-1)]
    e_DNA.append(Line(p_DNA[-1], p_DNA[0]))
    ll_DNA = LineLoop(e_DNA)

    Comment(' Membrane line loop requires extra work ')
    e_Membrane = [Line(p_DNA[2], p_Fluid[2]), Line(p_Fluid[3], p_DNA[3])]
    ll_Membrane = LineLoop([e_Membrane[0], e_Fluid[2], e_Membrane[1], '-%s' %e_DNA[2]])

    # Workaround PlaneSurface accepts only one LineLoop
    s_Fluid = PlaneSurface('%s' %','.join([ll_Fluid, ll_DNA, ll_Membrane]))
    s_DNA = PlaneSurface(ll_DNA)
    s_Membrane = PlaneSurface(ll_Membrane)

    Comment(' integrate crosssectional lines in fluid surface ')
    e_CrossS = [Line(p_DNA[k], p_Fluid[k+1]) for k in range(5,len(p_DNA))]
    e_CrossS.append(Line(p_DNA[0], p_Fluid[-1]))
    raw_code(['Line{%s} In Surface{%s};'  \
              %(e_CrossS[k], s_Fluid) for k in range(len(e_CrossS)-1)])


    # Define Fields for varying mesh size
    
    box1 = BoxField(lcDNA*5, lc, \
                    r0*0.4, r0*1.3, -l0*0.5-r0*0.4, l0*0.5+r0*0.4)
    box2 = BoxField(lcDNA*5, lc, \
                    r1-r0*0.3, r1+r0*0.6, -l0*0.5-r0*0.4, l0*0.5+r0*0.4)
    box3 = BoxField(lcDNA*5, lc, \
                    -1e-15, r0, -l0*0.55, l0*0.55)

    field_list = [box1, box2, box3]
    raw_code(['bfield = newf;'])
    raw_code(['Field[bfield] = Min;'])
    raw_code(['Field[bfield].FieldsList = {%s};' %', '.join(field_list)])
    raw_code(['Background Field = bfield;'])

    # to disable question dialogs
    raw_code(['General.ExpertMode = 1;'])
    # Don't extend the elements sizes from the boundary inside the domain
    raw_code(['Mesh.CharacteristicLengthExtendFromBoundary = 0;'])
    # 2D algorithm (1=MeshAdapt, 2=Automatic, 5=Delaunay, 6=Frontal, 7=bamg, 8=delquad)
    # only delaunay is compatible with attractor fields
    raw_code(['Mesh.Algorithm = 5;'])
    
    geo_dict = {"gmsh mesh generating sript": __name__,
                "Typical length scale": lc,
                "geo_code": get_code(),
            }
    return geo_dict


# -----
# to test script run '>python -m pkgs.geo.py4geo'
if __name__ == '__main__':
    from ..py4gmsh import *
    print(get_geo())
    print('\n - This is the sample code for the geo file')

else:
    from pkgs.py4gmsh import *
