from subprocess import call
from importlib import import_module
import os
import pkgs

def generate_mesh(clscale, gid, xml=True, dim=3, **params):
    """
    python function that writes geo for given geometry and xml for fenics

    Input: clscale... scaling of characteristic length in gmsh [float]
           gid ... geometry identifier [string]
           x0 ... midpoint of molecule [3-dim list]
           crosssections (kw)[bool][True]
           xml (kw)[bool][True]
    Out: geo_dict... file identifier dictionary + geo_dict
    """

    py4geo = "%s.py4geo" %gid
    exec('from %s import get_geo' %py4geo)
    
    # create path/to/pkgsdata/gid/mesh if not already there
    meshdir = os.path.join(pkgs.DATADIR, gid, "mesh")
    if not os.path.exists(meshdir):
        os.makedirs(meshdir)

    fid_dict = {"fid_geo": os.path.join(meshdir,"input.geo"),
                "fid_msh": os.path.join(meshdir,"out.msh"),
            }

    # save code to .geo file
    geo_dict = get_geo(**params)
    fobj = open(fid_dict["fid_geo"], "w")
    fobj.write(geo_dict["geo_code"])
    fobj.close()
    del geo_dict["geo_code"]

    # after writing the geo file, call gmsh
    gmsh_out = call(["gmsh", "-%s" %dim, "-v", "1","-clscale", "%f" %clscale,
                     fid_dict["fid_geo"], "-o", fid_dict["fid_msh"]])
    
    if gmsh_out < 0:
        raise RuntimeError('Gmsh failed in generating this geometry')
    if xml:
        fid_dict["fid_xml"] = os.path.join(meshdir,"mesh.xml")
        call(["dolfin-convert", fid_dict["fid_msh"], fid_dict["fid_xml"]])

    geo_dict.update(fid_dict)
    return geo_dict


# -----
# to test script run '>> python -m pkgs.geo2xml'
if __name__ == '__main__':
    print(get_mesh(
        clscale=7.0, gid="H_cyl_geo", x0=[0, 0e-9, 0e-9], xml=True)
    )
