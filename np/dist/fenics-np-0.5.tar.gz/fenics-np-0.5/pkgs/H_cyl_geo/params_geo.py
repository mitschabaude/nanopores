""" --- geometry parameters for Howorka --- """

nm = 1e-9

# @TODO maybe include tolc in parent file
tolc = 1e-14*nm  # tolerance for coordinate comparisons

# DNA radius
rDNA = 1.1*nm
# molecule radius
rMolecule = 0.5*rDNA
# effective pore radius
r0 = 1.1*rDNA
# barrel outer radius
r1 = 2.75*nm
# pore length
l0 = 15.0*nm
# membrane thickness
l1 = 2.2*nm
# Radius of domain
Rz = 15.0*nm
R = 15.0*nm
