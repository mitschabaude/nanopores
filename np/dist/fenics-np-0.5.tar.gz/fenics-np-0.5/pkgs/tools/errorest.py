from dolfin import *

__all__ = ["edge_residual_indicator","poisson_indicator","poisson_indicator_cyl","zz_indicator"]

def zz_indicator(v,flux=None,dx=None):
    """ v is assumed to be scalar and of piece-wise polynomial degree >= 1 """
    V = v.function_space()
    mesh = V.mesh()
    DV = VectorFunctionSpace(mesh, 'DG', V.ufl_element().degree()-1)
    #DV_e = VectorFunctionSpace(mesh, 'DG', V.ufl_element().degree())
    DV_e = VectorFunctionSpace(mesh, 'CG', V.ufl_element().degree())    
    DG = FunctionSpace(mesh, 'DG', 0)

    if not flux:
        flux = grad(v)

    # flux recovery
    # TODO: is there a better way to do this??
    # (project is slow and in theory unnessecary)
    
    g = project(flux,DV)
    g_e = project(g,DV_e)
    #g_e = Function(DV_e)
    #g_e.extrapolate(g)

    if not dx:
        dx = Measure("dx")

    w = TestFunction(DG)
    r = w*inner(g-g_e,g-g_e)*dx
    
    ind = Function(DG)
    assemble(r,tensor=ind.vector())
    err = errornorm(g_e,g,'L2')/norm(g,'L2')
    return ind,err

def edge_residual_indicator(mesh,flux,force=Constant(0.0)):
    residual = div(flux) + force
    W = FunctionSpace(mesh,"DG",0)
    w = TestFunction(W)
    n = FacetNormal(mesh)
    h = CellSize(mesh)
    r = w*(h*residual)**2*dx + avg(w)*avg(h)*jump(flux,n)**2*dS
    indicators = Function(W)
    b = indicators.vector()
    assemble(r,tensor=b)
    return indicators

def poisson_indicator(geo,x):
    mesh = geo.mesh
    (u,cp,cm) = x.split()
    W = FunctionSpace(mesh,"DG",0)
    w = TestFunction(W)
    n = FacetNormal(mesh)
    h = CellSize(mesh)

    dS = geo.dS()
    dx = geo.dx()

    Aperm = geo.pwconst("permittivity")
    from pkgs.physics.params_physical import eperm
    flux = Aperm*grad(u)/eperm

    res = avg(w)*avg(h)*jump(flux,n)**2*dS #+ w*(h*div(flux))**2*r*dx((2,3)) + w*(h*residual)**2*r*dx(1)
    restot = avg(h)*jump(flux,n)**2*dS
    energynorm = inner(avg(flux),avg(grad(u)))*dS

    indicators = Function(W)
    error = sqrt(assemble(restot)/assemble(energynorm))
    assemble(res,tensor=indicators.vector())
    return indicators,error

def poisson_indicator_cyl(geo,x):
    mesh = geo.mesh
    (u,cp,cm) = x.split()
    W = FunctionSpace(mesh,"DG",0)
    w = TestFunction(W)
    n = FacetNormal(mesh)
    h = CellSize(mesh)

    dS = geo.dS()
    dx = geo.dx()

    Aperm = geo.pwconst("permittivity")
    from pkgs.physics.params_physical import eperm
    flux = Aperm*grad(u)/eperm
    r = Expression("x[0]")

    res = avg(w)*avg(h)*jump(flux,n)**2*r('+')*dS
    restot = avg(h)*jump(flux,n)**2*r('+')*dS
    energynorm = inner(avg(flux),avg(grad(u)))*r('+')*dS

    indicators = Function(W)
    error = sqrt(assemble(restot)/assemble(energynorm))
    assemble(res,tensor=indicators.vector())
    return indicators,error

