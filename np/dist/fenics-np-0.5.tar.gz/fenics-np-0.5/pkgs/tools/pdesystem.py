""" General-purpose PDE System class """

from dolfin import *
from .illposed import *
from .errorest import *

parameters["refinement_algorithm"] = "plaza_with_parent_facets"

__all__ = ["PDESystem"]

class PDESystem(object):
    imax = 10
    maxcells = 5000
    marking_fraction = 0.5

    def __init__(self, geo, solvers, functions, functionals={}):
        self.geo = geo
        self.functions = functions
        self.solvers = solvers
        self.functionals = functionals

    def solve(self,refinement=False):

        if self.geo.mesh.num_cells() > self.maxcells:
            refinement = False

        for i in range(self.imax):
            print '\n- Loop ' +str(i+1) + ' of max.', self.imax

            self.single_solve()
            (ind,err) = self.estimate()

            if refinement:
                refined = self.refine(ind)
                if not refined:
                    print 'Maximal number of cells reached',  \
                           ' \n  ==> no more refinement \n'
                    break
        end

    def estimate(self):
        """ simple zz indicator, estimator """
        # just to have a basic estimation tool when nothing is defined
        u = self.solutions()[0]
        mesh = self.geo.mesh
        ind, err = zz_indicator(u)
        return ind, err

    def single_solve(self):
        for S in self.solvers.values(): S.solve()

    def refine(self,ind):
        mesh = self.refine_mesh(ind)
        if mesh.num_cells() > self.maxcells:
            return False
        
        self.adapt(mesh)
        return True
        
    def refine_mesh(self, ind):
        mesh = self.geo.mesh

        markers = CellFunction("bool",mesh)
        indicators = CellFunction("double",mesh)
        # TODO: parallel + efficient
        for c in cells(mesh):
            indicators[c] = ind(c.midpoint())

        # MARK
        dorfler_mark(markers,indicators,self.marking_fraction)

        # REFINE
        # TODO: use refine? adapt seems to crash sometimes
        mesh = refine(mesh, markers)
        #mesh = adapt(mesh, markers)
        return mesh
    
    def adapt(self, mesh):
        self.geo.adapt(mesh)
        
        for S in self.solvers.values():
            S.adapt(mesh)

        functions = tuple(self.functions.values())
        for S in self.solvers.values():
            S.replace(functions,functions)
            
        for J in self.functionals.values():
            J.adapt(mesh)
            J.replace(functions,functions)
            
    def rebuild(self, mesh):
        """ Assumes geometry to have geo.rebuild """
        functionals = self.functionals
        
        self.geo.rebuild(mesh)
        self.__init__(self.geo)
        
        for Jstr,J in self.functionals.items():
            J.values = functionals[Jstr].values
        
    def visualize(self):
        plot(self.geo.mesh,title="final mesh")
        
        for u in self.solutions():
            plot(u)

        interactive()
  
    def print_functionals(self):
        for Jstr,J in self.functionals.items():
            print ("%s: " %Jstr) + str(J.evaluate())

    def print_results(self):
        pass

    def solutions(self, string=None, deepcopy=False):
        if string:
            f = self.functions[string]
            if f.function_space().num_sub_spaces() > 0:
                return f.split(deepcopy=deepcopy)
            else:
                return (f,)
        t = ()
        for x in self.functions:
            t = t + self.solutions(x)
        return t
        
    def save_mesh(self, geo, name=None):
        if not name:
            name = "last_adapted_mesh"
        meshfile = File("pkgs/%s/mesh/%s.xml" %(geo,name))
        meshfile << self.geo.mesh
        N = str(self.geo.mesh.num_cells())
        meshfile = File("pkgs/%s/mesh/adapted/mesh_%s.xml" %(geo,N))
        meshfile << self.geo.mesh

